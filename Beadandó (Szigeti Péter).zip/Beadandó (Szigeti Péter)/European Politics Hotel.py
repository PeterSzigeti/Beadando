from abc import ABC, abstractmethod
from datetime import date, datetime

class Szoba(ABC):
    def __init__(self, ar, szobaszam):
        self.ar = ar
        self.szobaszam = szobaszam

    @abstractmethod
    def szoba_tipus(self):
        pass

    def __str__(self):
        return f"Szoba szám: {self.szobaszam}, Ár: {self.ar} €"

class EgyagyasSzoba(Szoba):
    def __init__(self, szobaszam, kilatas):
        super().__init__(50, szobaszam)
        self.kilatas = kilatas

    def szoba_tipus(self):
        return "Egyágyas Szoba"

    def __str__(self):
        return f"{super().__str__()}, Kilátás: {self.kilatas}"

class KetagyasSzoba(Szoba):
    def __init__(self, szobaszam, erkely):
        super().__init__(75, szobaszam)
        self.erkely = erkely

    def szoba_tipus(self):
        return "Kétágyas Szoba"

    def __str__(self):
        return f"{super().__str__()}, Erkéllyel: {'igen' if self.erkely else 'nem'}"

class Szalloda:
    def __init__(self, nev):
        self.nev = nev
        self.szobak = []
        self.foglalasok = []

    def hozzaad_szoba(self, szoba):
        if isinstance(szoba, Szoba):
            self.szobak.append(szoba)
        else:
            raise TypeError("Csak Szoba típusú objektumokat lehet hozzáadni.")

    def foglalas(self, vendeg_nev, foglalas_datum, szobaszam):
        if not isinstance(foglalas_datum, date):
            raise TypeError("A foglalás dátuma csak date típusú lehet.")

        if foglalas_datum <= date.today():
            raise ValueError("A foglalás dátumának jövőbeni dátumnak kell lennie.")
        
        foglalt_szoba = None
        for szoba in self.szobak:
            if szoba.szobaszam == szobaszam:
                foglalt_szoba = szoba
                break

        if foglalt_szoba is None:
            raise ValueError("Nincs ilyen szobaszámú szoba a szállodában.")
        
        for foglalas in self.foglalasok:
            if foglalas.szoba.szobaszam == szobaszam and foglalas.foglalas_datum == foglalas_datum:
                raise ValueError("A szoba már foglalt a megadott dátumra.")
        
        uj_foglalas = Foglalas(vendeg_nev, foglalas_datum, foglalt_szoba)
        self.foglalasok.append(uj_foglalas)
        return foglalt_szoba.ar

    def lemondas(self, vendeg_nev, foglalas_datum, szobaszam):
        if not isinstance(foglalas_datum, date):
            raise TypeError("A lemondás dátuma csak date típusú lehet.")
        
        for foglalas in self.foglalasok:
            if (foglalas.vendeg_nev == vendeg_nev and 
                foglalas.foglalas_datum == foglalas_datum and 
                foglalas.szoba.szobaszam == szobaszam):
                self.foglalasok.remove(foglalas)
                return f"Foglalás lemondva: Vendég neve: {vendeg_nev}, Dátum: {foglalas_datum}, Szoba szám: {szobaszam}"
        
        raise ValueError("Nincs ilyen foglalás.")

    def listaz_foglalasok(self):
        if not self.foglalasok:
            return "Nincs foglalás."
        foglalas_lista = "Foglalások:\n"
        for foglalas in self.foglalasok:
            foglalas_lista += f"  {foglalas}\n"
        return foglalas_lista

    def __str__(self):
        szalloda_info = f"Szálloda neve: {self.nev}\nSzobák:\n"
        for szoba in self.szobak:
            szalloda_info += f"  {szoba}\n"
        return szalloda_info

class Foglalas:
    def __init__(self, vendeg_nev, foglalas_datum, szoba):
        if not isinstance(szoba, Szoba):
            raise TypeError("Csak Szoba típusú objektumokat lehet foglalni.")
        if not isinstance(foglalas_datum, date):
            raise TypeError("A foglalás dátuma csak date típusú lehet.")
        self.vendeg_nev = vendeg_nev
        self.foglalas_datum = foglalas_datum
        self.szoba = szoba

    def __str__(self):
        return (f"Vendég neve: {self.vendeg_nev}, Foglalás dátuma: {self.foglalas_datum}, "
                f"Szoba: {self.szoba}")

def felhasznaloi_interfesz():
    szalloda = Szalloda("European Politics Hotel")

    egyagyas_szoba = EgyagyasSzoba(101, "tengerre néző")
    ketagyas_szoba = KetagyasSzoba(102, True)
    harmagyas_szoba = KetagyasSzoba(103, False)

    szalloda.hozzaad_szoba(egyagyas_szoba)
    szalloda.hozzaad_szoba(ketagyas_szoba)
    szalloda.hozzaad_szoba(harmagyas_szoba)

    foglalasok = [
        ("Szigeti Péter", date(2024, 6, 1), 101),
        ("Toroczkai László", date(2024, 6, 2), 102),
        ("Donát Anna", date(2024, 6, 3), 101),
        ("Orbán Viktor", date(2024, 6, 4), 103),
        ("Magyar Péter", date(2024, 6, 5), 101)
    ]

    for foglalas in foglalasok:
        try:
            ar = szalloda.foglalas(*foglalas)
            print(f"Foglalás sikeres. Vendég: {foglalas[0]}, Ár: {ar} €")
        except ValueError as e:
            print(f"Foglalási hiba: {e}")

    while True:
        print("\nÜdvözöllek a European Politics Hotel foglalási rendszerében")
        print("\nKérlek válassz az alábbi lehetőségek közül:")
        print("1. Szoba foglalása")
        print("2. Foglalás lemondása")
        print("3. Foglalások listázása")
        print("4. Kilépés")
        valasztas = input("\nVálassz egy lehetőséget (1-4): ")

        if valasztas == "1":
            vendeg_nev = input("Add meg a vendég nevét: ")
            datum_input = input("Add meg a foglalás dátumát (ÉÉÉÉ-HH-NN): ")
            try:
                foglalas_datum = date.fromisoformat(datum_input)
            except ValueError:
                print("Érvénytelen dátum formátum.")
                continue
            if foglalas_datum <= date.today():
                print("A foglalás dátumának jövőbeni dátumnak kell lennie.")
                continue
            try:
                szobaszam = int(input("Add meg a szobaszámot: "))
            except ValueError:
                print("A szobaszámnak egy számnak kell lennie.")
                continue
            try:
                ar = szalloda.foglalas(vendeg_nev, foglalas_datum, szobaszam)
                print(f"Foglalás sikeres. Ár: {ar} €")
            except ValueError as e:
                print(f"Foglalási hiba: {e}")

        elif valasztas == "2":
            vendeg_nev = input("Add meg a vendég nevét: ")
            datum_input = input("Add meg a foglalás dátumát (ÉÉÉÉ-HH-NN): ")
            try:
                foglalas_datum = date.fromisoformat(datum_input)
            except ValueError:
                print("Érvénytelen dátum formátum")
                continue
            try:
                szobaszam = int(input("Add meg a szobaszámot: "))
            except ValueError:
                print("A szobaszámnak egy számnak kell lennie")
                continue
            try:
                lemondas_uzenet = szalloda.lemondas(vendeg_nev, foglalas_datum, szobaszam)
                print(lemondas_uzenet)
            except ValueError as e:
                print(f"Lemondási hiba: {e}")

        elif valasztas == "3":
            print(szalloda.listaz_foglalasok())

        elif valasztas == "4":
            print("Kilépés...")
            break

        else:
            print("Érvénytelen választás.")

felhasznaloi_interfesz()